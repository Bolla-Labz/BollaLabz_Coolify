/**
 * Production-Grade Rate Limiting Middleware
 * Protects API from abuse and ensures fair usage across all endpoints
 */

import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import logger from '../config/logger.js';

dotenv.config();

/**
 * Custom rate limit handler with detailed logging and user-friendly responses
 */
const rateLimitHandler = (req, res) => {
  const resetTime = new Date(Date.now() + (req.rateLimit.resetTime || 0));
  const retryAfter = Math.ceil((resetTime - Date.now()) / 1000);

  logger.warn('Rate limit exceeded', {
    ip: req.ip,
    path: req.path,
    method: req.method,
    user: req.user?.id || 'unauthenticated',
    limit: req.rateLimit.limit,
    current: req.rateLimit.current
  });

  res.status(429).json({
    success: false,
    error: 'Too many requests',
    message: 'You have exceeded the rate limit. Please try again later.',
    retryAfter: `${retryAfter} seconds`,
    resetTime: resetTime.toISOString(),
    limit: req.rateLimit.limit,
    remaining: 0
  });
};

/**
 * Custom key generator to support per-user rate limiting after authentication
 */
const generateKey = (req) => {
  // If user is authenticated, use user ID + IP combination
  if (req.user?.id) {
    return `user:${req.user.id}:${req.ip}`;
  }
  // Otherwise, use IP address only
  return `ip:${req.ip}`;
};

/**
 * General API rate limiter - 100 requests per 15 minutes per IP
 * Applied to all /api/* routes
 */
export const generalLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
  message: {
    success: false,
    error: 'Too many requests',
    message: 'You have exceeded the general API rate limit. Please try again later.',
    retryAfter: '15 minutes'
  },
  standardHeaders: true, // Return rate limit info in RateLimit-* headers
  legacyHeaders: false, // Disable X-RateLimit-* headers
  handler: rateLimitHandler,
  keyGenerator: generateKey,
  skip: (req) => {
    // Skip for health check and root endpoints
    return req.path === '/health' || req.path === '/' || req.path === '/api/v1';
  }
});

/**
 * Auth endpoints rate limiter - 5 requests per 15 minutes per IP
 * Prevents brute force attacks on authentication endpoints
 */
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5,
  message: {
    success: false,
    error: 'Too many authentication attempts',
    message: 'Too many authentication attempts from this IP address. Please try again in 15 minutes.',
    retryAfter: '15 minutes'
  },
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitHandler,
  skipSuccessfulRequests: true // Don't count successful auth attempts
});

/**
 * Webhook endpoints rate limiter - 1000 requests per hour
 * Higher limit for legitimate webhook traffic
 */
export const webhookLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 1000,
  message: {
    success: false,
    error: 'Too many webhook requests',
    message: 'Webhook rate limit exceeded. Please contact support if this is a legitimate integration.',
    retryAfter: '1 hour'
  },
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitHandler
});

/**
 * Per-user rate limiter - 500 requests per hour (after authentication)
 * Applies to authenticated API requests
 */
export const perUserLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 500,
  message: {
    success: false,
    error: 'Per-user rate limit exceeded',
    message: 'You have exceeded your hourly request quota. Please try again later.',
    retryAfter: '1 hour'
  },
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitHandler,
  keyGenerator: (req) => {
    // Use user ID for authenticated requests
    return req.user?.id ? `user:${req.user.id}` : `ip:${req.ip}`;
  },
  skip: (req) => {
    // Only apply to authenticated requests
    return !req.user?.id;
  }
});

/**
 * Write operations rate limiter - 50 requests per 15 minutes
 * Applied to POST, PUT, DELETE operations
 */
export const writeLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 50,
  message: {
    success: false,
    error: 'Too many write requests',
    message: 'You have exceeded the write operation rate limit. Please try again later.',
    retryAfter: '15 minutes'
  },
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitHandler,
  keyGenerator: generateKey,
  skip: (req) => {
    // Only apply to write methods
    return !['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method);
  }
});

/**
 * Read operations rate limiter - 200 requests per 15 minutes
 * More permissive for GET operations
 */
export const readLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200,
  message: {
    success: false,
    error: 'Too many read requests',
    message: 'You have exceeded the read operation rate limit. Please try again later.',
    retryAfter: '15 minutes'
  },
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitHandler,
  keyGenerator: generateKey,
  skip: (req) => {
    // Only apply to read methods
    return req.method !== 'GET';
  }
});

/**
 * Middleware to add custom rate limit headers to all responses
 */
export const addRateLimitHeaders = (req, res, next) => {
  // Add custom X-RateLimit headers for better client compatibility
  const originalJson = res.json;
  res.json = function(data) {
    if (req.rateLimit) {
      res.set({
        'X-RateLimit-Limit': req.rateLimit.limit,
        'X-RateLimit-Remaining': req.rateLimit.remaining,
        'X-RateLimit-Reset': new Date(Date.now() + (req.rateLimit.resetTime || 0)).toISOString()
      });
    }
    return originalJson.call(this, data);
  };
  next();
};

/**
 * Export all rate limiters and utilities
 */
export default {
  generalLimiter,
  authLimiter,
  webhookLimiter,
  perUserLimiter,
  writeLimiter,
  readLimiter,
  addRateLimitHeaders
};
