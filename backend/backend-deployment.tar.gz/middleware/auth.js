import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import logger from '../config/logger.js';

dotenv.config();

// API Key Authentication Middleware
export const authenticateAPIKey = (req, res, next) => {
  // Skip authentication for webhook endpoints (they use signature validation instead)
  const webhookPaths = [
    '/api/v1/webhooks/twilio/sms',
    '/api/v1/webhooks/twilio/status',
    '/api/v1/webhooks/twilio/voice',
    '/api/v1/webhooks/twilio/test'
  ];

  if (webhookPaths.some(path => req.path.startsWith(path))) {
    logger.debug('Skipping API key auth for webhook endpoint', { path: req.path });
    return next();
  }

  const apiKey = req.headers['x-api-key'] || req.query.api_key;

  if (!apiKey) {
    logger.warn('API request without API key', { ip: req.ip, path: req.path });
    return res.status(401).json({
      success: false,
      error: 'API key required',
      message: 'Please provide an API key in X-API-Key header or api_key query parameter'
    });
  }

  if (apiKey !== process.env.API_KEY) {
    logger.warn('Invalid API key attempted', { ip: req.ip, path: req.path });
    return res.status(403).json({
      success: false,
      error: 'Invalid API key',
      message: 'The provided API key is not valid'
    });
  }

  logger.debug('API key authenticated', { path: req.path });
  next();
};

// JWT Authentication Middleware (for future user authentication)
export const authenticateJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      error: 'No token provided',
      message: 'Authorization header with Bearer token required'
    });
  }

  const token = authHeader.substring(7);

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    logger.warn('Invalid JWT token', { error: error.message });
    return res.status(403).json({
      success: false,
      error: 'Invalid token',
      message: 'The provided token is invalid or expired'
    });
  }
};

// Optional authentication - doesn't fail if no auth provided
export const optionalAuth = (req, res, next) => {
  const apiKey = req.headers['x-api-key'] || req.query.api_key;

  if (apiKey && apiKey === process.env.API_KEY) {
    req.authenticated = true;
  } else {
    req.authenticated = false;
  }

  next();
};

// Alias for authenticateAPIKey (for backwards compatibility)
export const requireAuth = authenticateAPIKey;
