import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;

// Database connection pool with optimized settings
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 5432,
  database: process.env.DB_NAME || 'bollalabz',
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  // Connection pool settings
  max: 20, // Maximum number of clients in the pool
  min: 2, // Minimum number of clients to keep in the pool
  idleTimeoutMillis: 30000, // Close idle clients after 30 seconds
  connectionTimeoutMillis: 2000, // Return an error after 2 seconds if connection could not be established
  // Performance settings
  statement_timeout: 10000, // Queries timeout after 10 seconds
  query_timeout: 10000, // Query timeout
  // Connection settings
  keepAlive: true,
  keepAliveInitialDelayMillis: 10000,
});

// Test database connection
pool.on('connect', () => {
  console.log('✓ Database connected successfully');
});

pool.on('error', (err) => {
  console.error('Unexpected database error:', err);
  process.exit(-1);
});

// Performance monitoring thresholds
const SLOW_QUERY_THRESHOLD = 100; // milliseconds
const VERY_SLOW_QUERY_THRESHOLD = 500; // milliseconds

// Query statistics
let queryStats = {
  total: 0,
  slow: 0,
  verySlow: 0,
  avgDuration: 0,
  totalDuration: 0
};

// Query helper function with performance monitoring
export const query = async (text, params) => {
  const start = Date.now();
  try {
    const result = await pool.query(text, params);
    const duration = Date.now() - start;

    // Update statistics
    queryStats.total++;
    queryStats.totalDuration += duration;
    queryStats.avgDuration = queryStats.totalDuration / queryStats.total;

    // Log query performance
    if (duration > VERY_SLOW_QUERY_THRESHOLD) {
      queryStats.verySlow++;
      console.warn('⚠️ VERY SLOW QUERY:', {
        duration: `${duration}ms`,
        query: text.substring(0, 100),
        rows: result.rowCount
      });
    } else if (duration > SLOW_QUERY_THRESHOLD) {
      queryStats.slow++;
      console.log('⏱️ Slow query:', {
        duration: `${duration}ms`,
        query: text.substring(0, 100),
        rows: result.rowCount
      });
    } else if (process.env.NODE_ENV === 'development') {
      console.log('✓ Query executed:', {
        duration: `${duration}ms`,
        rows: result.rowCount
      });
    }

    return result;
  } catch (error) {
    console.error('❌ Database query error:', {
      error: error.message,
      query: text.substring(0, 100)
    });
    throw error;
  }
};

// Get query statistics
export const getQueryStats = () => ({
  ...queryStats,
  avgDuration: Math.round(queryStats.avgDuration),
  slowQueryPercentage: queryStats.total > 0
    ? ((queryStats.slow / queryStats.total) * 100).toFixed(2) + '%'
    : '0%',
  verySlowQueryPercentage: queryStats.total > 0
    ? ((queryStats.verySlow / queryStats.total) * 100).toFixed(2) + '%'
    : '0%'
});

// Reset query statistics
export const resetQueryStats = () => {
  queryStats = {
    total: 0,
    slow: 0,
    verySlow: 0,
    avgDuration: 0,
    totalDuration: 0
  };
};

// Transaction helper
export const transaction = async (callback) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
};

export default pool;
