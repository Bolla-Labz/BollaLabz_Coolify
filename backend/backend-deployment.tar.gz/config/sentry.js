/**
 * Sentry Configuration for Backend
 * Error monitoring and performance tracking
 */

import * as Sentry from '@sentry/node';
import { nodeProfilingIntegration } from '@sentry/profiling-node';
import { execSync } from 'child_process';

/**
 * Get Git commit hash for release tracking
 */
function getGitCommitHash() {
  try {
    return execSync('git rev-parse HEAD').toString().trim();
  } catch (error) {
    return 'unknown';
  }
}

/**
 * Initialize Sentry for the backend
 * @param {import('express').Application} app - Express app instance
 */
export function initializeSentry(app) {
  const SENTRY_DSN = process.env.SENTRY_DSN;
  const NODE_ENV = process.env.NODE_ENV || 'development';

  // Skip Sentry initialization if no DSN is provided
  if (!SENTRY_DSN) {
    console.warn('⚠️  Sentry DSN not provided. Error monitoring disabled.');
    console.warn('   Set SENTRY_DSN in .env to enable error tracking.');
    return;
  }

  // Initialize Sentry
  Sentry.init({
    dsn: SENTRY_DSN,
    environment: NODE_ENV,

    // Release tracking (uses git commit hash)
    release: `bollalabz-backend@${getGitCommitHash()}`,

    // Performance Monitoring
    tracesSampleRate: NODE_ENV === 'production' ? 0.1 : 1.0, // 10% in prod, 100% in dev

    // Profiling
    profilesSampleRate: NODE_ENV === 'production' ? 0.1 : 1.0,

    integrations: [
      // Enable HTTP request tracking
      Sentry.httpIntegration({
        tracing: {
          // Track incoming HTTP requests
          captureIncomingHeaders: true,
          captureOutgoingHeaders: true,
        },
      }),

      // Enable Node profiling
      nodeProfilingIntegration(),

      // Capture console messages
      Sentry.captureConsoleIntegration({
        levels: ['error', 'warn'],
      }),

      // Context lines around errors
      Sentry.contextLinesIntegration(),

      // Local variables in stack traces
      Sentry.localVariablesIntegration(),

      // Module metadata
      Sentry.modulesIntegration(),

      // Request data
      Sentry.requestDataIntegration(),
    ],

    // Filter out sensitive data
    beforeSend(event, hint) {
      // Remove sensitive headers
      if (event.request?.headers) {
        delete event.request.headers['authorization'];
        delete event.request.headers['x-api-key'];
        delete event.request.headers['cookie'];
      }

      // Remove sensitive query params
      if (event.request?.query_string) {
        event.request.query_string = event.request.query_string
          .replace(/api_key=[^&]*/gi, 'api_key=[REDACTED]')
          .replace(/token=[^&]*/gi, 'token=[REDACTED]')
          .replace(/password=[^&]*/gi, 'password=[REDACTED]');
      }

      return event;
    },

    // Ignore specific errors
    ignoreErrors: [
      // Ignore client-side network errors
      'Network request failed',
      'NetworkError',
      'ECONNREFUSED',
      // Ignore rate limiting errors (these are expected)
      'Too Many Requests',
    ],
  });

  // Add Sentry request handler (must be first middleware)
  app.use(Sentry.Handlers.requestHandler({
    user: ['id', 'username', 'email'],
  }));

  // Add Sentry tracing middleware (must be after request handler)
  app.use(Sentry.Handlers.tracingHandler());

  console.log('✓ Sentry initialized successfully');
  console.log(`  Environment: ${NODE_ENV}`);
  console.log(`  Release: bollalabz-backend@${getGitCommitHash().substring(0, 7)}`);
}

/**
 * Get Sentry error handler middleware
 * Must be added BEFORE any other error handlers
 */
export function getSentryErrorHandler() {
  // Return a no-op middleware if Sentry is not initialized
  if (!process.env.SENTRY_DSN || !Sentry.Handlers) {
    return (err, req, res, next) => next(err);
  }

  return Sentry.Handlers.errorHandler({
    shouldHandleError(error) {
      // Capture all errors with status code >= 500
      return error.status >= 500;
    },
  });
}

/**
 * Manually capture an exception
 * @param {Error} error - Error to capture
 * @param {Object} context - Additional context
 */
export function captureException(error, context = {}) {
  Sentry.captureException(error, {
    extra: context,
  });
}

/**
 * Manually capture a message
 * @param {string} message - Message to capture
 * @param {string} level - Severity level (fatal, error, warning, info, debug)
 * @param {Object} context - Additional context
 */
export function captureMessage(message, level = 'info', context = {}) {
  Sentry.captureMessage(message, {
    level,
    extra: context,
  });
}

/**
 * Add breadcrumb for debugging
 * @param {string} message - Breadcrumb message
 * @param {string} category - Breadcrumb category
 * @param {Object} data - Additional data
 */
export function addBreadcrumb(message, category = 'default', data = {}) {
  Sentry.addBreadcrumb({
    message,
    category,
    data,
    level: 'info',
  });
}

/**
 * Set user context
 * @param {Object} user - User data
 */
export function setUser(user) {
  Sentry.setUser(user);
}

/**
 * Clear user context
 */
export function clearUser() {
  Sentry.setUser(null);
}

/**
 * Start a transaction for performance monitoring
 * @param {string} name - Transaction name
 * @param {string} op - Operation type
 * @returns {Object} Transaction object
 */
export function startTransaction(name, op = 'http.server') {
  return Sentry.startTransaction({
    name,
    op,
  });
}

export default Sentry;
