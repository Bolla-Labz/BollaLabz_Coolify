/**
 * Chat API Routes
 * Comprehensive AI chat with Claude, streaming, history, and tool execution
 */

import express from 'express';
import claudeService, { ConversationContext, AVAILABLE_TOOLS } from '../../../services/claude.js';
import logger from '../../../utils/logger.js';

const router = express.Router();

// In-memory conversation storage (TODO: move to database)
const conversations = new Map();

/**
 * Get or create conversation context for user
 */
function getConversation(userId) {
  if (!conversations.has(userId)) {
    conversations.set(userId, new ConversationContext());
  }
  return conversations.get(userId);
}

/**
 * Execute tool calls
 */
async function executeToolCall(toolName, toolInput) {
  logger.info(`Executing tool: ${toolName}`, toolInput);

  try {
    switch (toolName) {
      case 'searchContacts':
        // TODO: Implement actual contact search
        return {
          success: true,
          results: [
            {
              name: 'Example Contact',
              phone: '+1234567890',
              email: 'contact@example.com',
            },
          ],
          message: `Found ${1} contact(s) matching "${toolInput.query}"`,
        };

      case 'createTask':
        // TODO: Implement actual task creation
        return {
          success: true,
          taskId: `task_${Date.now()}`,
          task: {
            title: toolInput.title,
            priority: toolInput.priority,
            dueDate: toolInput.dueDate || null,
            description: toolInput.description || '',
          },
          message: `Task "${toolInput.title}" created with ${toolInput.priority} priority`,
        };

      case 'scheduleEvent':
        // TODO: Implement actual event scheduling
        return {
          success: true,
          eventId: `event_${Date.now()}`,
          event: {
            title: toolInput.title,
            startTime: toolInput.startTime,
            endTime: toolInput.endTime || null,
            location: toolInput.location || '',
          },
          message: `Event "${toolInput.title}" scheduled for ${toolInput.startTime}`,
        };

      case 'sendSMS':
        // TODO: Implement actual SMS sending via Twilio
        return {
          success: true,
          messageId: `msg_${Date.now()}`,
          to: toolInput.to,
          message: `SMS sent to ${toolInput.to}`,
        };

      case 'makeCall':
        // TODO: Implement actual call via Twilio
        return {
          success: true,
          callId: `call_${Date.now()}`,
          to: toolInput.to,
          message: `Call initiated to ${toolInput.to}`,
        };

      default:
        return {
          success: false,
          error: `Unknown tool: ${toolName}`,
        };
    }
  } catch (error) {
    logger.error(`Tool execution error: ${toolName}`, error);
    return {
      success: false,
      error: error.message,
    };
  }
}

/**
 * POST /api/v1/chat
 * Send a message and get AI response
 */
router.post('/', async (req, res) => {
  try {
    const { message, context = {}, useTools = true } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({
        success: false,
        error: 'Message is required',
      });
    }

    // Get user ID (from auth middleware - fallback to default)
    const userId = req.user?.id || 'default';

    // Get conversation context
    const conversation = getConversation(userId);

    // Add user message to context
    conversation.addUserMessage(message);

    // Build system prompt with user context
    const systemPrompt = claudeService.buildSystemPrompt({
      page: context.page,
      userName: req.user?.name || 'User',
      ...context,
    });

    // Prepare tools if enabled
    const tools = useTools ? AVAILABLE_TOOLS : null;

    // Call Claude API
    const result = await claudeService.chat(
      conversation.getMessages(),
      systemPrompt,
      tools
    );

    if (!result.success) {
      throw new Error('Failed to get response from Claude');
    }

    const response = result.response;

    // Handle tool calls if present
    let toolResults = [];
    if (response.stop_reason === 'tool_use') {
      for (const content of response.content) {
        if (content.type === 'tool_use') {
          const toolResult = await executeToolCall(content.name, content.input);
          toolResults.push({
            toolName: content.name,
            toolInput: content.input,
            result: toolResult,
          });

          // Add tool result to conversation
          conversation.addMessage('assistant', response.content);
          conversation.addMessage('user', [
            {
              type: 'tool_result',
              tool_use_id: content.id,
              content: JSON.stringify(toolResult),
            },
          ]);

          // Get follow-up response
          const followUp = await claudeService.chat(
            conversation.getMessages(),
            systemPrompt,
            tools
          );

          if (followUp.success) {
            response.content = followUp.response.content;
            result.cost.totalCost += followUp.cost.totalCost;
            result.cost.inputTokens += followUp.cost.inputTokens;
            result.cost.outputTokens += followUp.cost.outputTokens;
          }
        }
      }
    }

    // Extract text response
    const textContent = response.content.find(c => c.type === 'text');
    const responseText = textContent?.text || 'Sorry, I could not generate a response.';

    // Add assistant response to context
    conversation.addAssistantMessage(responseText);

    // Log cost
    logger.cost('claude-chat', result.cost.totalCost, {
      inputTokens: result.cost.inputTokens,
      outputTokens: result.cost.outputTokens,
    });

    res.json({
      success: true,
      response: responseText,
      toolsUsed: toolResults.length > 0,
      toolResults,
      cost: result.cost,
      messageCount: conversation.getMessages().length,
      timestamp: new Date().toISOString(),
    });

  } catch (error) {
    logger.error('Chat API error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to process chat message',
      message: error.message,
    });
  }
});

/**
 * POST /api/v1/chat/stream
 * Stream chat response from Claude
 */
router.post('/stream', async (req, res) => {
  try {
    const { message, context = {}, useTools = true } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({
        success: false,
        error: 'Message is required',
      });
    }

    // Set headers for SSE
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    // Get user ID
    const userId = req.user?.id || 'default';

    // Get conversation context
    const conversation = getConversation(userId);

    // Add user message to context
    conversation.addUserMessage(message);

    // Build system prompt
    const systemPrompt = claudeService.buildSystemPrompt({
      page: context.page,
      userName: req.user?.name || 'User',
      ...context,
    });

    // Prepare tools
    const tools = useTools ? AVAILABLE_TOOLS : null;

    let fullResponse = '';

    // Stream response
    const result = await claudeService.streamChat(
      conversation.getMessages(),
      systemPrompt,
      tools,
      (chunk) => {
        if (chunk.type === 'text') {
          fullResponse += chunk.text;
          res.write(`data: ${JSON.stringify({ type: 'text', text: chunk.text })}\n\n`);
        } else if (chunk.type === 'content_block_delta') {
          if (chunk.delta.type === 'text_delta') {
            fullResponse += chunk.delta.text;
            res.write(`data: ${JSON.stringify({ type: 'text', text: chunk.delta.text })}\n\n`);
          }
        }
      }
    );

    // Add assistant response to context
    conversation.addAssistantMessage(fullResponse);

    // Send final message with cost
    res.write(`data: ${JSON.stringify({
      type: 'done',
      cost: result.cost,
      messageCount: conversation.getMessages().length,
    })}\n\n`);

    // Log cost
    logger.cost('claude-stream', result.cost.totalCost, {
      inputTokens: result.cost.inputTokens,
      outputTokens: result.cost.outputTokens,
    });

    res.end();

  } catch (error) {
    logger.error('Chat stream API error:', error);
    res.write(`data: ${JSON.stringify({ type: 'error', error: error.message })}\n\n`);
    res.end();
  }
});

/**
 * GET /api/v1/chat/history
 * Get conversation history
 */
router.get('/history', async (req, res) => {
  try {
    const userId = req.user?.id || 'default';
    const conversation = getConversation(userId);

    res.json({
      success: true,
      messages: conversation.getMessages(),
      messageCount: conversation.getMessages().length,
      metadata: conversation.metadata,
    });

  } catch (error) {
    logger.error('Chat history API error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve chat history',
      message: error.message,
    });
  }
});

/**
 * POST /api/v1/chat/clear
 * Clear conversation history
 */
router.post('/clear', async (req, res) => {
  try {
    const userId = req.user?.id || 'default';
    const conversation = getConversation(userId);

    const previousCount = conversation.getMessages().length;
    conversation.clear();

    res.json({
      success: true,
      message: 'Conversation history cleared',
      clearedMessages: previousCount,
    });

  } catch (error) {
    logger.error('Chat clear API error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to clear chat history',
      message: error.message,
    });
  }
});

/**
 * GET /api/v1/chat/tools
 * Get available tools
 */
router.get('/tools', async (req, res) => {
  try {
    res.json({
      success: true,
      tools: AVAILABLE_TOOLS.map(tool => ({
        name: tool.name,
        description: tool.description,
        parameters: tool.input_schema.properties,
        required: tool.input_schema.required,
      })),
    });

  } catch (error) {
    logger.error('Chat tools API error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve tools',
      message: error.message,
    });
  }
});

export default router;
