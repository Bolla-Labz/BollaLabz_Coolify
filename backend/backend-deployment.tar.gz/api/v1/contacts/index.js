import express from 'express';
import { requireAuth } from '../../../middleware/auth.js';
import { body } from 'express-validator';
import Contact from '../../../models/Contact.js';
import Conversation from '../../../models/Conversation.js';
import { asyncHandler } from '../../../middleware/errorHandler.js';
import { handleValidationErrors, paginationValidators, searchValidator, phoneValidator, emailValidator } from '../../../validators/common.js';
import { readLimiter, writeLimiter } from '../../../middleware/rateLimiter.js';
import websocketService from '../../../services/websocket.js';

const router = express.Router();
router.use(requireAuth);

// GET /api/v1/contacts - List all contacts
router.get(
  '/',
  readLimiter,
  [...paginationValidators, searchValidator],
  handleValidationErrors,
  asyncHandler(async (req, res) => {
    const { page = 1, limit = 20, search = '', offset = 0 } = req.query;

    const result = await Contact.findAll({
      page: parseInt(page),
      limit: parseInt(limit),
      search,
      offset: parseInt(offset)
    });

    res.json({
      success: true,
      ...result
    });
  })
);

// GET /api/v1/contacts/:id - Get contact details
router.get(
  '/:id',
  readLimiter,
  asyncHandler(async (req, res) => {
    const contact = await Contact.findById(req.params.id);

    if (!contact) {
      return res.status(404).json({
        success: false,
        error: 'Contact not found',
        message: `No contact found with ID ${req.params.id}`
      });
    }

    res.json({
      success: true,
      data: contact
    });
  })
);

// POST /api/v1/contacts - Create contact
router.post(
  '/',
  writeLimiter,
  [
    phoneValidator('phone_number').notEmpty(),
    body('contact_name').optional().trim().isLength({ min: 1, max: 255 }),
    emailValidator('contact_email').optional(),
    body('notes').optional().isString()
  ],
  handleValidationErrors,
  asyncHandler(async (req, res) => {
    const { phone_number, contact_name, contact_email, notes } = req.body;

    // Check if contact with phone already exists
    const existing = await Contact.findByPhone(phone_number);
    if (existing) {
      return res.status(409).json({
        success: false,
        error: 'Contact already exists',
        message: `A contact with phone number ${phone_number} already exists`,
        data: existing
      });
    }

    const contact = await Contact.create({
      phone_number,
      contact_name,
      contact_email,
      notes
    });

    // Emit WebSocket event
    if (req.user?.id) {
      websocketService.emitContactCreated(req.user.id, contact);
    }

    res.status(201).json({
      success: true,
      message: 'Contact created successfully',
      data: contact
    });
  })
);

// PUT /api/v1/contacts/:id - Update contact
router.put(
  '/:id',
  writeLimiter,
  [
    body('contact_name').optional().trim().isLength({ min: 1, max: 255 }),
    emailValidator('contact_email').optional(),
    body('notes').optional().isString()
  ],
  handleValidationErrors,
  asyncHandler(async (req, res) => {
    const { contact_name, contact_email, notes } = req.body;

    const existing = await Contact.findById(req.params.id);
    if (!existing) {
      return res.status(404).json({
        success: false,
        error: 'Contact not found'
      });
    }

    // Only pass defined fields to update
    const updateData = {};
    if (contact_name !== undefined) updateData.contact_name = contact_name;
    if (contact_email !== undefined) updateData.contact_email = contact_email;
    if (notes !== undefined) updateData.notes = notes;

    if (Object.keys(updateData).length === 0) {
      return res.status(400).json({
        success: false,
        error: 'No fields to update',
        message: 'Please provide at least one field to update (contact_name, contact_email, or notes)'
      });
    }

    const contact = await Contact.update(req.params.id, updateData);

    // Emit WebSocket event
    if (req.user?.id) {
      websocketService.emitContactUpdated(req.user.id, contact);
    }

    res.json({
      success: true,
      message: 'Contact updated successfully',
      data: contact
    });
  })
);

// DELETE /api/v1/contacts/:id - Delete contact
router.delete(
  '/:id',
  writeLimiter,
  asyncHandler(async (req, res) => {
    const contact = await Contact.delete(req.params.id);

    if (!contact) {
      return res.status(404).json({
        success: false,
        error: 'Contact not found'
      });
    }

    // Emit WebSocket event
    if (req.user?.id) {
      websocketService.emitContactDeleted(req.user.id, req.params.id);
    }

    res.json({
      success: true,
      message: 'Contact deleted successfully',
      data: contact
    });
  })
);

// GET /api/v1/contacts/:id/conversations - Get contact's conversation history
router.get(
  '/:id/conversations',
  readLimiter,
  paginationValidators,
  handleValidationErrors,
  asyncHandler(async (req, res) => {
    const { page = 1, limit = 20 } = req.query;

    const contact = await Contact.findById(req.params.id);
    if (!contact) {
      return res.status(404).json({
        success: false,
        error: 'Contact not found'
      });
    }

    const result = await Conversation.findAll({
      contactId: req.params.id,
      page: parseInt(page),
      limit: parseInt(limit)
    });

    res.json({
      success: true,
      contact: {
        id: contact.id,
        contact_name: contact.contact_name,
        phone_number: contact.phone_number
      },
      ...result
    });
  })
);

// GET /api/v1/contacts/:id/analytics - Get contact analytics
router.get(
  '/:id/analytics',
  readLimiter,
  asyncHandler(async (req, res) => {
    const contact = await Contact.findById(req.params.id);
    if (!contact) {
      return res.status(404).json({
        success: false,
        error: 'Contact not found'
      });
    }

    const analytics = await Contact.getAnalytics(req.params.id);

    res.json({
      success: true,
      data: {
        contact: {
          id: contact.id,
          contact_name: contact.contact_name,
          phone_number: contact.phone_number,
          conversation_count: contact.conversation_count
        },
        analytics
      }
    });
  })
);

export default router;
