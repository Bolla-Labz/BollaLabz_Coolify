import { query } from '../config/database.js';

class Contact {
  // Get all contacts with pagination and search
  static async findAll({ page = 1, limit = 20, search = '', offset = 0 }) {
    const actualOffset = offset || (page - 1) * limit;

    let sql = `
      SELECT
        id, phone_number, contact_name, contact_email,
        conversation_count, last_contact_date,
        notes, created_at, updated_at
      FROM phone_contacts
    `;

    const params = [];

    if (search) {
      sql += ` WHERE contact_name ILIKE $1 OR phone_number ILIKE $1 OR contact_email ILIKE $1`;
      params.push(`%${search}%`);
    }

    sql += ` ORDER BY updated_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(limit, actualOffset);

    const result = await query(sql, params);

    // Get total count
    const countSql = search
      ? `SELECT COUNT(*) FROM phone_contacts WHERE contact_name ILIKE $1 OR phone_number ILIKE $1 OR contact_email ILIKE $1`
      : `SELECT COUNT(*) FROM phone_contacts`;
    const countParams = search ? [`%${search}%`] : [];
    const countResult = await query(countSql, countParams);

    return {
      data: result.rows,
      pagination: {
        page,
        limit,
        total: parseInt(countResult.rows[0].count),
        totalPages: Math.ceil(countResult.rows[0].count / limit)
      }
    };
  }

  // Find contact by ID
  static async findById(id) {
    const result = await query(
      'SELECT id, phone_number, contact_name, contact_email, conversation_count, last_contact_date, notes, created_at, updated_at FROM phone_contacts WHERE id = $1',
      [id]
    );
    return result.rows[0];
  }

  // Find contact by phone number
  static async findByPhone(phoneNumber) {
    const result = await query(
      'SELECT id, phone_number, contact_name, contact_email, conversation_count, last_contact_date, notes, created_at, updated_at FROM phone_contacts WHERE phone_number = $1',
      [phoneNumber]
    );
    return result.rows[0];
  }

  // Create new contact
  static async create({ phone_number, contact_name, contact_email, notes = null }) {
    const result = await query(
      `INSERT INTO phone_contacts
       (phone_number, contact_name, contact_email, notes, conversation_count, created_at, updated_at)
       VALUES ($1, $2, $3, $4, 0, NOW(), NOW())
       RETURNING id, phone_number, contact_name, contact_email, notes, conversation_count, created_at, updated_at`,
      [phone_number, contact_name, contact_email, notes]
    );
    return result.rows[0];
  }

  // Update contact
  static async update(id, { contact_name, contact_email, notes }) {
    const updates = [];
    const values = [];
    let paramCount = 1;

    if (contact_name !== undefined) {
      updates.push(`contact_name = $${paramCount++}`);
      values.push(contact_name);
    }
    if (contact_email !== undefined) {
      updates.push(`contact_email = $${paramCount++}`);
      values.push(contact_email);
    }
    if (notes !== undefined) {
      updates.push(`notes = $${paramCount++}`);
      values.push(notes);
    }

    if (updates.length === 0) {
      throw new Error('No fields to update');
    }

    updates.push(`updated_at = NOW()`);
    values.push(id);

    const result = await query(
      `UPDATE phone_contacts SET ${updates.join(', ')} WHERE id = $${paramCount} RETURNING id, phone_number, contact_name, contact_email, notes, conversation_count, created_at, updated_at`,
      values
    );
    return result.rows[0];
  }

  // Delete contact
  static async delete(id) {
    const result = await query(
      'DELETE FROM phone_contacts WHERE id = $1 RETURNING id, phone_number, contact_name, contact_email',
      [id]
    );
    return result.rows[0];
  }

  // Increment conversation count
  static async incrementConversationCount(id) {
    const result = await query(
      `UPDATE phone_contacts
       SET conversation_count = conversation_count + 1,
           last_contact_date = NOW(),
           updated_at = NOW()
       WHERE id = $1
       RETURNING id, phone_number, contact_name, contact_email, conversation_count, last_contact_date`,
      [id]
    );
    return result.rows[0];
  }

  // Get contact analytics
  static async getAnalytics(id) {
    const conversationStats = await query(
      `SELECT
         COUNT(*) as total_conversations,
         COUNT(CASE WHEN direction = 'inbound' THEN 1 END) as inbound_count,
         COUNT(CASE WHEN direction = 'outbound' THEN 1 END) as outbound_count,
         0 as total_cost
       FROM conversation_messages
       WHERE contact_id = $1`,
      [id]
    );

    const callStats = await query(
      `SELECT
         COUNT(*) as total_calls,
         
         SUM(cost_amount) as total_call_cost
       FROM call_costs cc
       JOIN conversation_messages cm ON cm.id = cc.conversation_message_id
       WHERE cm.contact_id = $1`,
      [id]
    );

    return {
      conversations: conversationStats.rows[0],
      calls: callStats.rows[0]
    };
  }
}

export default Contact;
