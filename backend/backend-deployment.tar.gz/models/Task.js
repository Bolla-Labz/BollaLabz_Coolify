import { query, transaction } from '../config/database.js';

class Task {
  // Get all tasks with filters
  static async findAll({ page = 1, limit = 20, status, priority, assignee }) {
    const offset = (page - 1) * limit;
    const params = [];
    let paramCount = 1;

    let sql = `
      SELECT
        id, title, description, status, priority,
        assignee, due_date, dependencies,
        metadata, created_at, updated_at, completed_at
      FROM scheduled_tasks
      WHERE 1=1
    `;

    if (status) {
      sql += ` AND status = $${paramCount++}`;
      params.push(status);
    }

    if (priority) {
      sql += ` AND priority = $${paramCount++}`;
      params.push(priority);
    }

    if (assignee) {
      sql += ` AND assignee = $${paramCount++}`;
      params.push(assignee);
    }

    sql += ` ORDER BY
      CASE priority
        WHEN 'urgent' THEN 1
        WHEN 'high' THEN 2
        WHEN 'medium' THEN 3
        WHEN 'low' THEN 4
      END,
      due_date ASC NULLS LAST
      LIMIT $${paramCount++} OFFSET $${paramCount++}`;
    params.push(limit, offset);

    const result = await query(sql, params);

    // Count
    let countSql = 'SELECT COUNT(*) FROM scheduled_tasks WHERE 1=1';
    const countParams = [];
    let countIdx = 1;

    if (status) {
      countSql += ` AND status = $${countIdx++}`;
      countParams.push(status);
    }
    if (priority) {
      countSql += ` AND priority = $${countIdx++}`;
      countParams.push(priority);
    }
    if (assignee) {
      countSql += ` AND assignee = $${countIdx++}`;
      countParams.push(assignee);
    }

    const countResult = await query(countSql, countParams);

    return {
      data: result.rows,
      pagination: {
        page,
        limit,
        total: parseInt(countResult.rows[0].count),
        totalPages: Math.ceil(countResult.rows[0].count / limit)
      }
    };
  }

  // Find task by ID
  static async findById(id) {
    const result = await query('SELECT * FROM scheduled_tasks WHERE id = $1', [id]);
    return result.rows[0];
  }

  // Create new task
  static async create({ title, description, status = 'pending', priority = 'medium', assignee, due_date, dependencies = [], metadata = {} }) {
    const result = await query(
      `INSERT INTO scheduled_tasks
       (title, description, status, priority, assignee, due_date, dependencies, metadata, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())
       RETURNING *`,
      [title, description, status, priority, assignee, due_date, JSON.stringify(dependencies), JSON.stringify(metadata)]
    );
    return result.rows[0];
  }

  // Update task
  static async update(id, updates) {
    const fields = [];
    const values = [];
    let paramCount = 1;

    const allowedFields = ['title', 'description', 'status', 'priority', 'assignee', 'due_date', 'dependencies', 'metadata'];

    for (const field of allowedFields) {
      if (updates[field] !== undefined) {
        fields.push(`${field} = $${paramCount++}`);
        values.push(
          field === 'dependencies' || field === 'metadata'
            ? JSON.stringify(updates[field])
            : updates[field]
        );
      }
    }

    if (fields.length === 0) {
      throw new Error('No fields to update');
    }

    // Auto-set completed_at if status is completed
    if (updates.status === 'completed') {
      fields.push(`completed_at = NOW()`);
    }

    fields.push(`updated_at = NOW()`);
    values.push(id);

    const result = await query(
      `UPDATE scheduled_tasks SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *`,
      values
    );
    return result.rows[0];
  }

  // Delete task
  static async delete(id) {
    const result = await query(
      'DELETE FROM scheduled_tasks WHERE id = $1 RETURNING *',
      [id]
    );
    return result.rows[0];
  }

  // Get overdue tasks
  static async getOverdue() {
    const result = await query(
      `SELECT * FROM scheduled_tasks
       WHERE status != 'completed'
       AND due_date < NOW()
       ORDER BY due_date ASC`,
      []
    );
    return result.rows;
  }

  // Get today's tasks
  static async getToday() {
    const result = await query(
      `SELECT * FROM scheduled_tasks
       WHERE status != 'completed'
       AND DATE(due_date) = CURRENT_DATE
       ORDER BY priority, due_date ASC`,
      []
    );
    return result.rows;
  }

  // Add dependency
  static async addDependency(taskId, dependencyId) {
    return await transaction(async (client) => {
      // Get current dependencies
      const task = await client.query('SELECT dependencies FROM scheduled_tasks WHERE id = $1', [taskId]);
      if (task.rows.length === 0) {
        throw new Error('Task not found');
      }

      const dependencies = task.rows[0].dependencies || [];
      if (!dependencies.includes(dependencyId)) {
        dependencies.push(dependencyId);
      }

      // Update
      const result = await client.query(
        'UPDATE scheduled_tasks SET dependencies = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
        [JSON.stringify(dependencies), taskId]
      );
      return result.rows[0];
    });
  }

  // Remove dependency
  static async removeDependency(taskId, dependencyId) {
    return await transaction(async (client) => {
      const task = await client.query('SELECT dependencies FROM scheduled_tasks WHERE id = $1', [taskId]);
      if (task.rows.length === 0) {
        throw new Error('Task not found');
      }

      const dependencies = (task.rows[0].dependencies || []).filter(id => id !== dependencyId);

      const result = await client.query(
        'UPDATE scheduled_tasks SET dependencies = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
        [JSON.stringify(dependencies), taskId]
      );
      return result.rows[0];
    });
  }
}

export default Task;
