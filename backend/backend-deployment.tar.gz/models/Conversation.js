import { query } from '../config/database.js';

class Conversation {
  // Get all conversations with filters
  static async findAll({ page = 1, limit = 20, contactId, startDate, endDate, direction }) {
    const offset = (page - 1) * limit;
    const params = [];
    let paramCount = 1;

    let sql = `
      SELECT
        cm.*,
        pc.name as contact_name,
        pc.phone_number
      FROM conversation_messages cm
      LEFT JOIN phone_contacts pc ON cm.contact_id = pc.id
      WHERE 1=1
    `;

    if (contactId) {
      sql += ` AND cm.contact_id = $${paramCount++}`;
      params.push(contactId);
    }

    if (startDate) {
      sql += ` AND cm.timestamp >= $${paramCount++}`;
      params.push(startDate);
    }

    if (endDate) {
      sql += ` AND cm.timestamp <= $${paramCount++}`;
      params.push(endDate);
    }

    if (direction) {
      sql += ` AND cm.direction = $${paramCount++}`;
      params.push(direction);
    }

    sql += ` ORDER BY cm.timestamp DESC LIMIT $${paramCount++} OFFSET $${paramCount++}`;
    params.push(limit, offset);

    const result = await query(sql, params);

    // Get total count with same filters
    let countSql = 'SELECT COUNT(*) FROM conversation_messages cm WHERE 1=1';
    const countParams = [];
    let countParamIdx = 1;

    if (contactId) {
      countSql += ` AND cm.contact_id = $${countParamIdx++}`;
      countParams.push(contactId);
    }
    if (startDate) {
      countSql += ` AND cm.timestamp >= $${countParamIdx++}`;
      countParams.push(startDate);
    }
    if (endDate) {
      countSql += ` AND cm.timestamp <= $${countParamIdx++}`;
      countParams.push(endDate);
    }
    if (direction) {
      countSql += ` AND cm.direction = $${countParamIdx++}`;
      countParams.push(direction);
    }

    const countResult = await query(countSql, countParams);

    return {
      data: result.rows,
      pagination: {
        page,
        limit,
        total: parseInt(countResult.rows[0].count),
        totalPages: Math.ceil(countResult.rows[0].count / limit)
      }
    };
  }

  // Find conversation by ID
  static async findById(id) {
    const result = await query(
      `SELECT
         cm.*,
         pc.name as contact_name,
         pc.phone_number,
         pc.email
       FROM conversation_messages cm
       LEFT JOIN phone_contacts pc ON cm.contact_id = pc.id
       WHERE cm.id = $1`,
      [id]
    );
    return result.rows[0];
  }

  // Get conversation by conversation_id (group messages together)
  static async findByConversationId(conversationId, { page = 1, limit = 50 }) {
    const offset = (page - 1) * limit;

    const result = await query(
      `SELECT
         cm.*,
         pc.name as contact_name,
         pc.phone_number
       FROM conversation_messages cm
       LEFT JOIN phone_contacts pc ON cm.contact_id = pc.id
       WHERE cm.conversation_id = $1
       ORDER BY cm.timestamp ASC
       LIMIT $2 OFFSET $3`,
      [conversationId, limit, offset]
    );

    const countResult = await query(
      'SELECT COUNT(*) FROM conversation_messages WHERE conversation_id = $1',
      [conversationId]
    );

    return {
      data: result.rows,
      pagination: {
        page,
        limit,
        total: parseInt(countResult.rows[0].count),
        totalPages: Math.ceil(countResult.rows[0].count / limit)
      }
    };
  }

  // Create new conversation message
  static async create({
    conversation_id,
    contact_id,
    direction,
    content,
    message_type = 'sms',
    cost = 0,
    metadata = {}
  }) {
    const result = await query(
      `INSERT INTO conversation_messages
       (conversation_id, contact_id, direction, content, message_type, cost, metadata, timestamp)
       VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
       RETURNING *`,
      [conversation_id, contact_id, direction, content, message_type, cost, JSON.stringify(metadata)]
    );
    return result.rows[0];
  }

  // Update message
  static async update(id, { content, metadata }) {
    const updates = [];
    const values = [];
    let paramCount = 1;

    if (content !== undefined) {
      updates.push(`content = $${paramCount++}`);
      values.push(content);
    }
    if (metadata !== undefined) {
      updates.push(`metadata = $${paramCount++}`);
      values.push(JSON.stringify(metadata));
    }

    if (updates.length === 0) {
      throw new Error('No fields to update');
    }

    values.push(id);

    const result = await query(
      `UPDATE conversation_messages SET ${updates.join(', ')} WHERE id = $${paramCount} RETURNING *`,
      values
    );
    return result.rows[0];
  }

  // Search messages
  static async search({ searchTerm, contactId, page = 1, limit = 20 }) {
    const offset = (page - 1) * limit;
    const params = [`%${searchTerm}%`];
    let paramCount = 2;

    let sql = `
      SELECT
        cm.*,
        pc.name as contact_name,
        pc.phone_number
      FROM conversation_messages cm
      LEFT JOIN phone_contacts pc ON cm.contact_id = pc.id
      WHERE cm.content ILIKE $1
    `;

    if (contactId) {
      sql += ` AND cm.contact_id = $${paramCount++}`;
      params.push(contactId);
    }

    sql += ` ORDER BY cm.timestamp DESC LIMIT $${paramCount++} OFFSET $${paramCount++}`;
    params.push(limit, offset);

    const result = await query(sql, params);

    // Count
    let countSql = 'SELECT COUNT(*) FROM conversation_messages WHERE content ILIKE $1';
    const countParams = [`%${searchTerm}%`];

    if (contactId) {
      countSql += ' AND contact_id = $2';
      countParams.push(contactId);
    }

    const countResult = await query(countSql, countParams);

    return {
      data: result.rows,
      pagination: {
        page,
        limit,
        total: parseInt(countResult.rows[0].count),
        totalPages: Math.ceil(countResult.rows[0].count / limit)
      }
    };
  }

  // Delete conversation
  static async delete(id) {
    const result = await query(
      'DELETE FROM conversation_messages WHERE id = $1 RETURNING *',
      [id]
    );
    return result.rows[0];
  }
}

export default Conversation;
