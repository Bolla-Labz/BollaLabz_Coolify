/**
 * WebSocket Service - Real-time Communication
 * Handles Socket.IO server setup, authentication, and event management
 */

import { Server } from 'socket.io';
import jwt from 'jsonwebtoken';
import logger from '../config/logger.js';

class WebSocketService {
  constructor() {
    this.io = null;
    this.connectedClients = new Map();
  }

  /**
   * Initialize Socket.IO server
   * @param {http.Server} httpServer - Express HTTP server
   */
  initialize(httpServer) {
    this.io = new Server(httpServer, {
      cors: {
        origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
        credentials: true,
        methods: ['GET', 'POST']
      },
      transports: ['websocket', 'polling'],
      pingTimeout: 60000,
      pingInterval: 25000
    });

    // Authentication middleware
    this.io.use((socket, next) => {
      const token = socket.handshake.auth.token;

      if (!token) {
        return next(new Error('Authentication token required'));
      }

      try {
        // Verify JWT token
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'bollalabz-secret-key');
        socket.userId = decoded.userId;
        socket.userEmail = decoded.email;
        next();
      } catch (error) {
        logger.error('WebSocket authentication failed:', error);
        next(new Error('Invalid authentication token'));
      }
    });

    // Connection handler
    this.io.on('connection', (socket) => {
      const { userId, userEmail } = socket;

      logger.info(`WebSocket client connected: ${socket.id} (User: ${userEmail})`);

      // Store connected client
      this.connectedClients.set(socket.id, {
        socketId: socket.id,
        userId,
        userEmail,
        connectedAt: new Date().toISOString()
      });

      // Join user-specific room
      socket.join(`user:${userId}`);

      // Send welcome message
      socket.emit('connection:established', {
        message: 'WebSocket connection established',
        socketId: socket.id,
        timestamp: new Date().toISOString()
      });

      // Handle disconnection
      socket.on('disconnect', (reason) => {
        logger.info(`WebSocket client disconnected: ${socket.id} (Reason: ${reason})`);
        this.connectedClients.delete(socket.id);
      });

      // Handle client ping
      socket.on('ping', () => {
        socket.emit('pong', { timestamp: new Date().toISOString() });
      });

      // Handle errors
      socket.on('error', (error) => {
        logger.error(`WebSocket error for ${socket.id}:`, error);
      });
    });

    logger.info('✓ WebSocket service initialized successfully');
  }

  /**
   * Emit event to specific user
   * @param {string} userId - User ID
   * @param {string} event - Event name
   * @param {object} data - Event data
   */
  emitToUser(userId, event, data) {
    if (!this.io) {
      logger.warn('WebSocket not initialized');
      return;
    }

    this.io.to(`user:${userId}`).emit(event, {
      ...data,
      timestamp: new Date().toISOString()
    });

    logger.debug(`Event emitted to user ${userId}: ${event}`);
  }

  /**
   * Emit event to all connected clients
   * @param {string} event - Event name
   * @param {object} data - Event data
   */
  emitToAll(event, data) {
    if (!this.io) {
      logger.warn('WebSocket not initialized');
      return;
    }

    this.io.emit(event, {
      ...data,
      timestamp: new Date().toISOString()
    });

    logger.debug(`Event broadcasted to all clients: ${event}`);
  }

  /**
   * Get connected clients count
   * @returns {number}
   */
  getConnectedClientsCount() {
    return this.connectedClients.size;
  }

  /**
   * Get connected clients info
   * @returns {Array}
   */
  getConnectedClients() {
    return Array.from(this.connectedClients.values());
  }

  /**
   * Check if user is connected
   * @param {string} userId - User ID
   * @returns {boolean}
   */
  isUserConnected(userId) {
    return Array.from(this.connectedClients.values()).some(
      client => client.userId === userId
    );
  }

  // ===== Contact Events =====

  emitContactCreated(userId, contact) {
    this.emitToUser(userId, 'contact:created', { contact });
  }

  emitContactUpdated(userId, contact) {
    this.emitToUser(userId, 'contact:updated', { contact });
  }

  emitContactDeleted(userId, contactId) {
    this.emitToUser(userId, 'contact:deleted', { contactId });
  }

  // ===== Task Events =====

  emitTaskCreated(userId, task) {
    this.emitToUser(userId, 'task:created', { task });
  }

  emitTaskUpdated(userId, task) {
    this.emitToUser(userId, 'task:updated', { task });
  }

  emitTaskDeleted(userId, taskId) {
    this.emitToUser(userId, 'task:deleted', { taskId });
  }

  emitTaskStatusChanged(userId, taskId, oldStatus, newStatus) {
    this.emitToUser(userId, 'task:status-changed', {
      taskId,
      oldStatus,
      newStatus
    });
  }

  // ===== Message/Conversation Events =====

  emitMessageReceived(userId, message) {
    this.emitToUser(userId, 'message:received', { message });
  }

  emitConversationUpdated(userId, conversation) {
    this.emitToUser(userId, 'conversation:updated', { conversation });
  }

  // ===== Calendar Events =====

  emitCalendarEventCreated(userId, event) {
    this.emitToUser(userId, 'calendar:event-created', { event });
  }

  emitCalendarEventUpdated(userId, event) {
    this.emitToUser(userId, 'calendar:event-updated', { event });
  }

  emitCalendarEventDeleted(userId, eventId) {
    this.emitToUser(userId, 'calendar:event-deleted', { eventId });
  }

  // ===== Workflow Events =====

  emitWorkflowTriggered(userId, workflow) {
    this.emitToUser(userId, 'workflow:triggered', { workflow });
  }

  emitWorkflowCompleted(userId, workflowId, result) {
    this.emitToUser(userId, 'workflow:completed', { workflowId, result });
  }

  emitWorkflowFailed(userId, workflowId, error) {
    this.emitToUser(userId, 'workflow:failed', { workflowId, error });
  }

  // ===== People/CRM Events =====

  emitPersonCreated(userId, person) {
    this.emitToUser(userId, 'person:created', { person });
  }

  emitPersonUpdated(userId, person) {
    this.emitToUser(userId, 'person:updated', { person });
  }

  emitPersonDeleted(userId, personId) {
    this.emitToUser(userId, 'person:deleted', { personId });
  }
}

// Export singleton instance
const websocketService = new WebSocketService();
export default websocketService;
