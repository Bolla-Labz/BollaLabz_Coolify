/**
 * BollaLabz Backend Server
 * Main Express server with all integrations
 */

import express, { Express, Request, Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
import { createWebhookRouter } from './webhooks/router';
import { createTestRouter } from './tests/integration-tests';
import { logger, LogLevel } from './utils/logger';

// Load environment variables
dotenv.config();

// Set log level from environment
if (process.env.LOG_LEVEL) {
  const level = LogLevel[process.env.LOG_LEVEL as keyof typeof LogLevel];
  if (level !== undefined) {
    logger.setLevel(level);
  }
}

const app: Express = express();
const PORT = process.env.PORT || 4000;

// Middleware
app.use(helmet()); // Security headers
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true,
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Request logging
app.use((req: Request, res: Response, next) => {
  logger.info(`${req.method} ${req.path}`);
  next();
});

// Health check
app.get('/health', (req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
  });
});

// API Routes
app.get('/api/v1', (req: Request, res: Response) => {
  res.json({
    message: 'BollaLabz API v1',
    endpoints: {
      webhooks: '/api/v1/webhooks',
      test: '/api/v1/test',
      costs: '/api/v1/test/costs/current',
    },
  });
});

// Webhook routes
try {
  const webhookRouter = createWebhookRouter();
  app.use('/api/v1/webhooks', webhookRouter);
  logger.info('Webhook routes initialized');
} catch (error) {
  logger.error('Failed to initialize webhook routes', error);
}

// Test routes (only in development)
if (process.env.NODE_ENV !== 'production') {
  try {
    const testRouter = createTestRouter();
    app.use('/api/v1/test', testRouter);
    logger.info('Test routes initialized (development only)');
  } catch (error) {
    logger.error('Failed to initialize test routes', error);
  }
}

// Error handling
app.use((err: any, req: Request, res: Response, next: any) => {
  logger.error('Unhandled error', err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
  });
});

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).json({
    error: 'Not found',
    path: req.path,
  });
});

// Start server
app.listen(PORT, () => {
  logger.info(`BollaLabz Backend Server running on port ${PORT}`);
  logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
  logger.info(`Frontend URL: ${process.env.FRONTEND_URL || 'http://localhost:5173'}`);
});

export default app;
